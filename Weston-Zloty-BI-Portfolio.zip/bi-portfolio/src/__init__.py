"""Business intelligence portfolio pipelines."""
